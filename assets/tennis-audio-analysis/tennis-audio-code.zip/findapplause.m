close all;
% function [] = findapplause(point, noisethreshold)
point = 5;
noisethreshold = 0.33;
% Load audio 
[match, fs] = audioread('game_original.mp3');
ts = 1/fs;
audio = match(:,1);

% constants for rally isolation
r1a = .02;
r1b = .11;
r2a = .25;
r2b = .375;
r3a = .52;
r3b = .60;
r4a = .75;
r4b = .82;
r5a = .897;
r5b = .99;

rally1 = audio(r1a*length(audio):r1b*length(audio)); % 2 hits, result: 15-0
rally2 = audio(r2a*length(audio):r2b*length(audio)); % 3 hits, 30-0
rally3 = audio(r3a*length(audio):r3b*length(audio)); % 6 hits, 30-15
rally4 = audio(r4a*length(audio):r4b*length(audio)); % 2 hits, 40-15
rally5 = audio(r5a*length(audio):r5b*length(audio)); % 6 hits, game pt

% modify to hear specific rally
% sound(rally5, fs)

% figure;

emptySize = 0.15 * fs; % transfer time to frequency
sweepSize = 0.05 * fs; % transfer time to frequency

rally = rally2; % choose rally here (rally 1-5)

t = 0:ts:(length(rally)*ts)-ts;
size_time = length(t);
result_plot = zeros(1, size_time);

for i = emptySize+1:size_time-emptySize
    if(rally(i) > noisethreshold)
        take1 = rally(i-emptySize:i-emptySize+sweepSize-2);
        %take2 = rally(i+emptySize-sweepSize+1:i+emptySize);
        cc1 = take1 > 0.1; 
        %cc2 = take2 > 0.1; 
        if (sum(cc1) / sweepSize >= 0.23) %&& (sum(cc2) / sweepSize >= 0.15)
            % if noise is too much (frequency > 0.1) then ignore this value
            result_plot(i) = 1;
        end
   end    
end
% for i = emptySize+1:size_time-emptySize
%     if(rally(i) > noisethreshold)
%         take1 = rally(i-emptySize:i-emptySize+sweepSize-1);
%         take2 = rally(i+emptySize-sweepSize+1:i+emptySize);
%         cc1 = take1 > 0.07; 
%         cc2 = take2 > 0.07; 
%         if (sum(cc1) / sweepSize >= 0.08) && (sum(cc2) / sweepSize >= 0.08)
%             % if noise is too much (frequency > 0.1) then ignore this value
%             result_plot(i) = 1;
%         end
%    end    
% end


maxBound = 0.08 * fs;
minBound = 0.04 * fs;
errorMargin = 0.008 * fs;

c = find(result_plot > 0);
index = 1;
while index <= length(c)-1
    if(c(index+1) - c(index) <= errorMargin)
        result_plot(c(index):c(index+1)) = 1;
    else
        index = index+1;
        check = find(c >= c(index)-maxBound & c <= c(index)-maxBound+minBound, 1);
        if(~isempty(check)) 
            temp = c(index);
%             while (index <= length(c)) && (c(index) - temp <= minBound)
%                 index = index+1;
%             end
            index = index-1;
            result_plot(temp: c(index)) = 0;
        end
    end
    index = index+1;
end


%returns only one point for applause for each case of applause, instead of
%100
% j = 1;
% applause = find(result_plot > 0);
% foundapplause = 0;
% while j <= length(result_plot)-1
%     if result_plot(j) > 0
%         b = j+1;
%         while b <= j+350000
%             result_plot(b) = 0;
%             b = b+1;
%         end
%     end
% %     j=j+1;
% %     if result_plot(j)> 0
% %         b=j;
% %         while b <= j+1000
% %             result_plot(b) = 0;
% %         end
% %     end
%  
%     j=j+1;
% end
hold on;
title("Applause identification");
xlabel("time");
lightBlue = [91, 207, 244] / 255; 
ylabel("magnitude");
plot(t, rally);
plot(t, result_plot);