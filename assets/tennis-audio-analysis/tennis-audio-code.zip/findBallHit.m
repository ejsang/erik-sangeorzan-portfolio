function [times_plot, ball_hits_total, ball_hits_vec, net_hits_vec, net] = findBallHit(point, noisethreshold)

% Load audio 
[match, fs] = audioread('game_original.mp3');
ts = 1/fs;
audio = match(:,1);

% constants for rally isolation
r1a = .02;
r1b = .11;
r2a = .25;
r2b = .375;
r3a = .52;
r3b = .60;
r4a = .75;
r4b = .82;
r5a = .897;
r5b = .99;

rally1 = audio(r1a*length(audio):r1b*length(audio)); % 2 hits, result: 15-0
rally2 = audio(r2a*length(audio):r2b*length(audio)); % 3 hits, 30-0
rally3 = audio(r3a*length(audio):r3b*length(audio)); % 6 hits, 30-15
rally4 = audio(r4a*length(audio):r4b*length(audio)); % 2 hits, 40-15
rally5 = audio(r5a*length(audio):r5b*length(audio)); % 6 hits, game pt

% modify the 2 constants to hear specific rally
% sound(rally5, fs)

% uncomment these to see the clips
% plot(t,audio);
% plot(t1,rally1);
% plot(t2,rally2);
% plot(t3,rally3);
% plot(t4,rally4);
% plot(t5,rally5);
% xlabel('Time (s)');
% ylabel('Magnitude');
% title('Wimbledon 2019 Rally -- Time Domain');

% figure;

if (point == 1) rally = rally1; 
elseif (point == 2) rally = rally2; 
elseif (point == 3) rally = rally3; 
elseif (point == 4) rally = rally4; 
elseif (point == 5) rally = rally5; 
end

t = 0:ts:(length(rally)*ts)-ts;
size_time = length(t);

nearThreshold = 0.08;
nearEndSize = 0.05 * fs;
nearBeginSize = 0.03 * fs;
emptySize = 0.15 * fs; % transfer time to frequency
sweepSize = 0.05 * fs; % transfer time to frequency

netThreshold = 0.096;
netEndSize = 0.07 * fs;
netBeginSize = 0.09 * fs;

ball_hits_vec = [];
net_hits_vec = [0];
ball_hits_total = 0;
times_plot = zeros(1, size_time);

net_plot = zeros(1, size_time);

for j = emptySize+1:size_time-emptySize
    if(rally(j) > noisethreshold) % every scanned sound needs to be larger than noisethreshold
        
        range1 = rally(j-emptySize:j-emptySize+sweepSize-1); % ____xxxx____i__________
        range2 = rally(j+emptySize-sweepSize+1:j+emptySize); % ____________i____xxxx__
        
        count1 = abs(range1) > 0.07; % may adjust this value for better result
        count2 = abs(range2) > 0.07; % basically it counts the amount of noise above (0.07)
       
        range3 = rally(j+nearBeginSize:j+nearEndSize); % ______i__xx___ % identify distinct feature of ball hit 
        count3 = abs(range3) > nearThreshold;
        
        range4 = rally(j+netBeginSize:j+netEndSize); % ______i____xx__ % identify distinct feature of net hIt 
        count4 = abs(range4) > netThreshold;
        
        if (sum(count1) / sweepSize <= 0.08) && (sum(count2) / sweepSize <= 0.08) && (sum(count3) / (nearEndSize-nearBeginSize) <= 0.08)
            % if too many noise (frequency > 0.08) 
            % and no special feature of ball hit then ignore this value
            % otherwise recognise it as a ball hit (need another filter later)
            times_plot(j) = 1;
        elseif (sum(count1) / sweepSize <= 0.08) && (sum(count2) / sweepSize <= 0.08) && (sum(count4) / (netEndSize-netBeginSize) <= 0.015)
            % if too many noise (frequency > 0.08) 
            % and no special feature of net hit then ignore this value
            % otherwise recognise it as a net hit (need another filter later) 
            net_plot(j) = 1;  
            
        end
   end    
end

errorMargin = 0.008 * fs; % determine whether sound is the same hit 
matchIntervalSize = 5 * fs; % interval between match (5s)
netSoundSize = 1 * fs;

maxBound = 0.08 * fs; % use max and min to identify additional sound
minBound = 0.04 * fs; 

hitTime = find(times_plot > 0); % find the exact time of hit
netTime = find(net_plot > 0);

if ~isempty(hitTime)
    ball_hits_total = 1;
    ball_hits_vec = 1;
    % for loop is to isolate net hit from ball hit
    for i = 1:length(netTime)
        check = find(hitTime >= netTime(i)-errorMargin & hitTime <= netTime(i)+errorMargin, 1);
        if(~isempty(check))
            net_plot(netTime(i)) = 0;
        elseif(i < length(netTime)) && (netTime(i+1)-netTime(i) <= errorMargin)
            net_plot(netTime(i):netTime(i+1)) = 1;
        end
    end
end

index = 1;
while index <= length(hitTime)-1
    if(hitTime(index+1) - hitTime(index) <= errorMargin) %% determine if the sound is same ball hit 
        times_plot(hitTime(index):hitTime(index+1)) = 1;
        index = index+1;
    else
        
        index = index+1;
        check = find(hitTime >= hitTime(index)-maxBound & hitTime <= hitTime(index)-maxBound+minBound, 1);
        % check for if this ball hit sound is an additional
        if(~isempty(check)) 
            temp = hitTime(index);
            while (index <= length(hitTime)) && (hitTime(index) - temp <= minBound)
                index = index+1;
            end
            times_plot(temp: hitTime(index-1)) = 0; % cancel out additional sound
        end
        if(index ~= length(hitTime)+1)
            if(hitTime(index) - hitTime(index-1) > matchIntervalSize) %% update number of ballHit
                ball_hits_vec = [ball_hits_vec, 1];
                netCheck = find(net_plot(hitTime(index-1):hitTime(index-1) + netSoundSize) > 0, 1);
                if(~isempty(netCheck)) 
                    net_hits_vec(end) = net_hits_vec(end)+1;
                end
                net_hits_vec = [net_hits_vec, 0];
            else
                ball_hits_vec(end) = ball_hits_vec(end) + 1;
            end
            ball_hits_total = ball_hits_total + 1;
        else
            netCheck = find(net_plot(hitTime(index-1):hitTime(index-1) + netSoundSize) > 0, 1);
            if(~isempty(netCheck)) 
                net_hits_vec(end) = net_hits_vec(end)+1;
            end
        end
    end
end

figure;
hold on;

% uncomment these lines to overlay rally plot with detected ball hits
plot(t, rally);
plot(t, times_plot, '--r');
plot(t, net_plot, '--g');
legend('Rally', 'Ball hits', 'Net hits');
title(['Rally ', num2str(point), ' with detected ball and net hits']);
xlabel('Time (s)');
ylabel('Magnitude');

net = net_plot(net_plot>0);