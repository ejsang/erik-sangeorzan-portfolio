Project website: https://ejsang.wixsite.com/eecs351project

To run our code, simply run the main.m file.
This is the driver of our program.

Main calls our ballHit and outidentification algorithms to gather the necessary information about the point (aka rally).
Running main will print output in the console for each point and the running game score. 
It will also open plots for each rally with detected ball hits and net hits.

The while loop in main runs until one player reaches the score needed to win a game.
However, because our algorithm misses a net hit in rally 4, the program will throw an error after rally 5, since the game should have ended after that rally (but does not as the score is wrong via the missing net hit in rally 4).

Further included is the progress we made on an audience detection algorithm (findapplause.m), which would be utilized for rally automation in our future development.
This is not called in main but can be run on its own. You can choose which of the five rallies to analyze in line 36.
Much like the outidentification alg, it reads in the audio, determines which range of values to analyze, then runs and creates the new double with the identifying 1's for where there is applause. This is overlaid on a plot of the rally.
