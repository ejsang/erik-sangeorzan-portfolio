close all;
% finding time when ball hit
noisethreshold = 0.33; %% below this value is considered noise 
% emptyTime = 0.2;  
% sweepTime = 0.15;

% if ball hit is t, then the duration from t-emptytime to t-emptytime+sweeptime 
% should not contains noise, similarily for t+emptytime
% [times_plot, ball_hits] = findBallHit(t1, fs, rally1, noisethreshold, 0.2, 0.15); % modify
% times_plot is the result

% loop for a game
serverScore = 0;
returnerScore = 0;
point = 1;
while (serverScore < 4 && returnerScore < 4)
    [times_plot, ball_hits, ball_hits_vec, net_hits_vec, net] = findBallHit(point, noisethreshold);
    [out] = outidentification(point);
    % point winner determination
    winner = 0; % 0=server, 1=returner
    net = size(net,2) > 1;
    if (mod(ball_hits, 2) == 0) % even num hits
        if (out || net) % out or ball hits net
            winner=0; % server wins
            serverScore = serverScore + 1;
        else
            winner=1; % returner wins
            returnerScore = returnerScore + 1;
        end

    else % odd num hits
        if (out || net) % out or ball hits net
            winner=1; % returner wins
            returnerScore = returnerScore + 1;
        else
            winner=0; % server wins
            serverScore = serverScore + 1;
        end
    end

    % point results
    fprintf('Point %i results:\n', point);
    fprintf('  Number of ball hits: %i\n', ball_hits);
    fprintf('  OUT was called:      ');
    if (out == 1) fprintf('True\n');
    else fprintf('False\n');
    end
    fprintf('  Ball hit the net:    ');
    if (net == 1) fprintf('True\n'); %#ok<*SEPEX>
    else fprintf('False\n');
    end
    fprintf('  Winner of the point: ')
    if (winner == 1) fprintf('Returner\n');
    else fprintf('Server\n');
    end 
    
    % game score
    fprintf('Current game score:\n');
    fprintf('  Server:   ');
    if (serverScore == 0) fprintf('0\n');
    elseif (serverScore == 1) fprintf('15\n');
    elseif (serverScore == 2) fprintf('30\n');
    elseif (serverScore == 3) fprintf('40\n');
    elseif (serverScore == 4) fprintf('Wins game\n');
    end
    
    fprintf('  Returner: ');
    if (returnerScore == 0) fprintf('0\n');
    elseif (returnerScore == 1) fprintf('15\n');
    elseif (returnerScore == 2) fprintf('30\n');
    elseif (returnerScore == 3) fprintf('40\n');
    elseif (returnerScore == 4) fprintf('Wins game\n');
    end
    fprintf('\n');
    
    point = point + 1;
end


