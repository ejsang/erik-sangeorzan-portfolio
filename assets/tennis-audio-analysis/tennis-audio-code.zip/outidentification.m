function [out] = outidentification(point)
% Load audio 
[match, fs] = audioread('game_ModOut.mp3');
ts = 1/fs;
t = 0:ts:(length(match(:,1))*ts)-ts;
audio = match(:,1);

out = audio(.969*length(audio):.9705*length(audio));
% sound(out,fs)
outlength = length(out);
t1 = 0:ts:(length(out)*ts)-ts;
% plot(t1,out);
%soundsc(out,fs);

% constants for rally isolation
r1a = .02;
r1b = .11;
r2a = .25;
r2b = .375;
r3a = .52;
r3b = .60;
r4a = .75;
r4b = .82;
r5a = .897;
r5b = .99;

rally1 = audio(r1a*length(audio):r1b*length(audio)); % 2 hits, result: 15-0
rally2 = audio(r2a*length(audio):r2b*length(audio)); % 3 hits, 30-0
rally3 = audio(r3a*length(audio):r3b*length(audio)); % 6 hits, 30-15
rally4 = audio(r4a*length(audio):r4b*length(audio)); % 2 hits, 40-15
rally5 = audio(r5a*length(audio):r5b*length(audio)); % 6 hits, game pt, has OUT

% figure;

if (point == 1) rally = rally1; 
elseif (point == 2) rally = rally2; 
elseif (point == 3) rally = rally3; 
elseif (point == 4) rally = rally4; 
elseif (point == 5) rally = rally5; 
end

testaudio = rally;
t2 = 0:ts:(length(testaudio)*ts)-ts;
% plot(t2,testaudio);

i = 1;
coeffs = zeros(100000,2);
iteration = 1;
outtimes = zeros(100,1);
incstep = 100;
detectionthreshold = 0.1;
activationthreshold = 0.3;
datapoints = 0;
while (i < length(testaudio) - outlength)
    z = corrcoef(out, testaudio(i:i+outlength-1));
    correlation = abs(z(1,2));
    coeffs(iteration,1)=correlation;
    coeffs(iteration,2) = t2(i);
    if correlation > activationthreshold
        incstep = 10000;
        datapoints = datapoints + 1;
        outtimes(datapoints,1) = t2(i);
    elseif correlation > detectionthreshold 
        incstep = 10;
    else
        incstep = 100;
    end
    i = i + incstep;
    iteration = iteration+1;
end

out = outtimes > 0;
out = numel(out(out>0));