"""
This script provides the user interface for our project. Uses multithreading with a process for collecting audio samples, performing ICA and audio playback.
All processes are started on initialization.

ICA(): If more than ica_samp audio samples have been collected since the last ICA iteration, then ICA will be performed on the next ica_samp samples.
Resulting output from this function is spliced and appended to previously calculated input

playback(): When ICA output is available, sounddevice is used to play the recovered audio channels

getsamples(): Searches for .npy files containing input audio data that are created by multiproc_cogent.py*.
When the required .npy files are available, they are processed into the input buffer

*When running on the Raspberry Pi, with full hardware setup
"""
import sys
import click
import time
import threading
from scipy.io import wavfile
import math
import os
import sounddevice
import numpy as np
import logging
from PyQt5.QtWidgets import QWidget, QPushButton, QApplication, QGridLayout, QRadioButton, QVBoxLayout, QHBoxLayout
from PyQt5 import QtCore
import matplotlib
matplotlib.use('Qt5Agg')
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
from matplotlib.figure import Figure

logging.basicConfig(level = logging.INFO)

class Test(QWidget):
    """docstring..."""
    """Make sure these are correct"""
    filedir = os.getcwd() + "/npy/" # npy files location
    num_mics = 3 # number of inputs/mics. Can be 2 or 3
    fs = 44100 # 15000
    """Changing these may improve performance"""
    plotlastsamples = 48000 # number of samples to plot from end of output list
    wait_per_plot = 0.3 # time between plot refresh
    """Probably don't need to be changed"""
    ica_samp = 48000 # samples per ICA
    timesec = 3 # minimum seconds of audio to play back
    sleep_ica = 3 # seconds before starting ica
    sleep_playback = 5 # seconds before enabling playback
    wait_per_play = 5 # time to wait if play unsuccessful
    wait_per_load = 0.1 # time to wait between each npy load
    wait_per_ICA = 0.05 # time to wait between each ICA iteration
    check_play_refresh = 0.1 # wait time before checking if something is played
    delete_files_after_reading = False # delete files after loading them, to save memory
    """Don't modify variables below here"""
    buffer = [] # list of num_mics lists, populated by getsamples()
    output = [] # ica output: separated audio
    readind = 0 # current index of buffer, incremented by ica
    adding_to_buffer = False # don't start ICA while samples are being added
    timeindex = 0 # current index of output, incremented by playback
    setIndex = 0 # used by playback buttons
    playTrack = -1 # track to play
    resetIndex = False # used by playback buttons
    paused = False # true if paused
    shutdown = False # set to true when Quit button pressed

    def __init__(self):
        super().__init__()

        layoutBase = QGridLayout()
        self.setLayout(layoutBase)
        layout = QGridLayout()
        layoutBase.addLayout(layout, 0, 0)

        self.qbtn = QPushButton("QUIT", self)
        self.qbtn.clicked.connect(self.quit)
        self.qbtn.resize(self.qbtn.sizeHint())
        # self.qbtn.move(50, 50)
        layout.addWidget(self.qbtn, 0, 0)

        self.pausePlaybackbtn = QPushButton("Pause", self)
        self.pausePlaybackbtn.clicked.connect(self.pausePlayback)
        self.pausePlaybackbtn.resize(self.pausePlaybackbtn.sizeHint())
        # self.pausePlaybackbtn.move(50, 100)
        layout.addWidget(self.pausePlaybackbtn, 3, 0)

        self.playPlaybackbtn = QPushButton("Play", self)
        self.playPlaybackbtn.clicked.connect(self.playPlayback)
        self.playPlaybackbtn.resize(self.playPlaybackbtn.sizeHint())
        # self.playPlaybackbtn.move(50, 100)
        layout.addWidget(self.playPlaybackbtn, 4, 0)

        self.back5secbtn = QPushButton("Back 5 sec", self)
        self.back5secbtn.clicked.connect(self.back5sec)
        self.back5secbtn.resize(self.back5secbtn.sizeHint())
        # self.back5secbtn.move(50, 100)
        layout.addWidget(self.back5secbtn, 5, 0)

        self.forw5secbtn = QPushButton("Forw 5 sec", self)
        self.forw5secbtn.clicked.connect(self.forw5sec)
        self.forw5secbtn.resize(self.forw5secbtn.sizeHint())
        # self.forw5secbtn.move(50, 100)
        layout.addWidget(self.forw5secbtn, 5, 1)

        self.stopPlaybackbtn = QPushButton("Stop", self)
        self.stopPlaybackbtn.clicked.connect(self.stopPlayback)
        self.stopPlaybackbtn.resize(self.stopPlaybackbtn.sizeHint())
        # self.stopPlaybackbtn.move(50, 100)
        layout.addWidget(self.stopPlaybackbtn, 6, 0)

        self.radiobutton0 = QRadioButton("Track 0")
        # self.radiobutton0.setChecked(True)
        self.radiobutton0.tracknumbr = 0
        self.radiobutton0.toggled.connect(self.onClicked)
        layout.addWidget(self.radiobutton0, 2, 0)

        self.radiobutton1 = QRadioButton("Track 1")
        self.radiobutton1.tracknumbr = 1
        self.radiobutton1.toggled.connect(self.onClicked)
        layout.addWidget(self.radiobutton1, 2, 1)

        if self.num_mics == 3:
            self.radiobutton2 = QRadioButton("Track 2")
            self.radiobutton2.tracknumbr = 2
            self.radiobutton2.toggled.connect(self.onClicked)
            layout.addWidget(self.radiobutton2, 2, 2)

        self.plot0 = MplCanvas(self, width=4, height=4, dpi=100)
        layoutBase.addWidget(self.plot0, 1, 0)

        self.plot1 = MplCanvas(self, width=4, height=4, dpi=100)
        layoutBase.addWidget(self.plot1, 1, 1)

        if self.num_mics == 3:
            self.plot2 = MplCanvas(self, width=4, height=4, dpi=100)
            layoutBase.addWidget(self.plot2, 1, 2)

        self.plotTimer = QtCore.QTimer()
        self.plotTimer.setInterval(self.wait_per_plot*1000)
        self.plotTimer.timeout.connect(self.update_plot_data)
        self.plotTimer.start()

        # self.setGeometry(300, 300, 350, 250)
        self.setWindowTitle('Source Separation')

        self.show()

        getsamples_thread = threading.Thread(target=self.getsamples)
        getsamples_thread.start()
        ica_thread = threading.Thread(target=self.ica)
        ica_thread.start()
        playback_thread = threading.Thread(target=self.playback)
        playback_thread.start()

    def onClicked(self):
        radioButton = self.sender()
        if radioButton.isChecked():
            self.playTrack = radioButton.tracknumbr
            self.paused = False
            sounddevice.stop()
            logging.info("Playing track %d", self.playTrack)

    def stopPlayback(self):
        self.playTrack = -1
        if self.paused:
            self.timeindex = 0
        else:
            self.resetIndex = True
        sounddevice.stop()

    def pausePlayback(self):
        self.paused = True
        sounddevice.stop()

    def playPlayback(self):
        if self.playTrack == -1:
            if self.radiobutton0.isChecked():
                self.playTrack = 0
            elif self.radiobutton1.isChecked():
                self.playTrack = 1
            elif self.num_mics == 3 and self.radiobutton2.isChecked():
                self.playTrack = 2
            else:
                self.playTrack = 0
                self.radiobutton0.setChecked(True)
        self.paused = False

    def back5sec(self):
        if self.paused or self.playTrack == -1:
            self.setIndex = self.timeindex - 5*self.fs
            if self.setIndex < 0:
                self.timeindex = 0
            elif self.setIndex > len(self.output[0]):
                self.timeindex = len(self.output[0])
            else:
                self.timeindex = self.setIndex
            self.setIndex = 0
        else:
            self.setIndex = self.timeindex - 5*self.fs
        sounddevice.stop()

    def forw5sec(self):
        if self.paused or self.playTrack == -1:
            self.setIndex = self.timeindex + 5*self.fs
            if self.setIndex < 0:
                self.timeindex = 0
            elif self.setIndex > len(self.output[0]):
                self.timeindex = len(self.output[0])
            else:
                self.timeindex = self.setIndex
            self.setIndex = 0
        else:
            self.setIndex = self.timeindex + 5*self.fs
        sounddevice.stop()

    def update_plot_data(self):
        # logging.info("Updating plots")
        if len(self.output) > 0:
            if len(self.output[0]) > self.plotlastsamples:
                self.plot0.axes.clear()
                self.plot0.axes.plot(self.output[0][-self.plotlastsamples:])
                self.plot0.draw()
                self.plot1.axes.clear()
                self.plot1.axes.plot(self.output[1][-self.plotlastsamples:])
                self.plot1.draw()
                if self.num_mics == 3:
                    self.plot2.axes.clear()
                    self.plot2.axes.plot(self.output[2][-self.plotlastsamples:])
                    self.plot2.draw()

    def playback(self):
        self.timeindex = 0
        time.sleep(self.sleep_playback)
        timeincr = self.fs*self.timesec
        while True:
            if self.shutdown:
                break
            if self.resetIndex:
                self.timeindex = 0
                self.resetIndex = False
            if self.playTrack != -1 and not self.paused:
                if len(self.output[0]) - self.timeindex >=timeincr:
                    tmptimeindex = len(self.output[self.playTrack])
                    startTime = time.time()
                    logging.info("Playback: Playing track %d from samples %d to %d", self.playTrack, self.timeindex, tmptimeindex)
                    sounddevice.play(self.output[self.playTrack][self.timeindex:], samplerate=self.fs, blocking=True)
                    totalTime = time.time() - startTime
                    playedSamples = round(totalTime * self.fs)
                    if self.resetIndex:
                        self.timeindex = 0
                        self.resetIndex = False
                    elif self.setIndex != 0:
                        if self.setIndex < 0:
                            self.timeindex = 0
                        elif self.setIndex > tmptimeindex:
                            self.timeindex = tmptimeindex
                        else:
                            self.timeindex = self.setIndex
                        self.setIndex = 0
                    else:
                        if self.timeindex + playedSamples > tmptimeindex:
                            self.timeindex = tmptimeindex
                        else:
                            self.timeindex += playedSamples
                    logging.info("Playback: Playback stopped at %d sample, after %f seconds and %d samples", self.timeindex, totalTime, playedSamples)
                else:
                    logging.info("Playback: Waiting for more samples from ICA")
                    time.sleep(self.wait_per_play)
            else:
                time.sleep(self.check_play_refresh)

    def ica(self):
        """Simulates ica by adding the samples in buffer, and appending them to output"""
        ica_input = []
        ica_output = []
        N = self.num_mics
        # M = np.random.uniform(low=0.5, high=2, size=(N,N)) ### first guess for mixing matrix
        stored_overlap = np.zeros((N, int(self.ica_samp/10)))
        W = None
        maxtime = 10000
        minvalue = 0.000005
        time.sleep(self.sleep_ica)
        for enum in range(self.num_mics):
            self.output.append([])
            ica_input.append([])
            ica_output.append([])
        # readind indicates current index. readind = 0: haven't read from buffer yet. readind = end: done reading from buffer
        # Runs ica when there are more than or equal to ica_samp unread samples left in buffer
        while True:
            if self.shutdown:
                break
            if not self.adding_to_buffer and len(self.buffer[0]) - self.readind >= self.ica_samp:
                logging.info("ICA: Performing ICA on samples %d to %d", self.readind, self.readind+self.ica_samp)
                START = time.time()
                for ica_in, buff in zip(ica_input, self.buffer):
                    ica_in += buff[self.readind:(self.readind+self.ica_samp)]
                START = time.time()
                logging.debug("TIME 1 IS %f", time.time() - START)
                # Mix audios to simulate ICA
                # Convert list of lists to np array
                ica_inarray = np.asarray(ica_input)
                ica_outarray = np.asarray(ica_output)
                self.output = np.asarray(self.output)
                if self.output.size > 0: # b/c we don't add overlap on first iteration
                    temp = ica_inarray[:, -int(self.ica_samp/10):]
                    ica_inarray = np.concatenate((stored_overlap, ica_inarray), axis=1)
                    stored_overlap = temp
                else:
                    stored_overlap = ica_inarray[:,-int(self.ica_samp/10):]

                # X = np.matmul(M, ica_inarray)
                X = ica_inarray
                centered_input = data_Cen(X)
                whitened_input = data_whi(centered_input)
                ica_outarray, W = do_fastICA(whitened_input, maxtime, minvalue, W)
                if self.output.size == 0:
                    self.output = ica_outarray
                else:
                    self.output = splicing(ica_outarray, self.output, int(self.ica_samp/10))

                # Mix audios end. ica_out is simulated ICA output
                logging.debug("TIME 2 IS %f", time.time() - START)
                START = time.time()
                for ic in range(len(ica_input)):
                    ica_input[ic] = []
                    ica_output[ic] = []
                logging.debug("TIME 3 IS %f", time.time() - START)
                self.readind += self.ica_samp
                logging.info("ICA: Accumulated ICA output length: %d", len(self.output[0]))
                iter_without_ica = 0
            else:
                time.sleep(self.wait_per_ICA)
        # wavfile.write("aaa.wav", self.fs, np.asarray(self.output[0]))
        # logging.info("Getsamples: Buffer dtype: %s", str((np.asarray(self.output[0])).dtype))
        # out_sum = []
        # for out in self.output:
        #     out_sum += out
        # sounddevice.play(out_sum, samplerate=self.fs)

    def getsamples(self):
        """Simulates reading in samples by loading buffer from input .wav files"""
        for enum in range(self.num_mics):
            self.buffer.append([])
        logging.info("Getsamples: Buffer length: %d", len(self.buffer[0]))
        ser_num = 0
        while True:
            if self.shutdown:
                break
            time.sleep(self.wait_per_load)
            ser_filenames = []
            tmpbool = False
            for i in range(self.num_mics):
                ser_name = self.filedir + "out" + str(i) + "_" + str(ser_num) + ".npy"
                ser_filenames.append(ser_name)
                if not os.path.exists(ser_name):
                    tmpbool = True
                    break
            if tmpbool:
                continue
            self.adding_to_buffer = True
            for i in range(self.num_mics):
                self.buffer[i] += list(np.load(ser_filenames[i]))
                if self.delete_files_after_reading:
                    os.remove(ser_filenames[i])
            self.adding_to_buffer = False
            ser_num += 1
            logging.info("Getsamples: Buffer length: %d", len(self.buffer[0]))
        # sounddevice.play(buff_sum, samplerate=self.fs)

    def quit(self):
        """Shuts down the application and stops all threads"""
        self.shutdown = True
        self.playTrack = -1
        sounddevice.stop()
        time.sleep(1.5)
        self.close()


class MplCanvas(FigureCanvasQTAgg):

    def __init__(self, parent=None, width=4, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = self.fig.add_subplot(111)
        super(MplCanvas, self).__init__(self.fig)


def data_Cen(x):
    m, n = np.shape(x)
    mean = np.mean(x, axis=1)
    mean = np.reshape(mean, (m, 1))
    x = x - mean
    return x


# input x should have been centralized
def data_whi(x, maxeig=None):
    m, n = np.shape(x)
    if maxeig == None:
        maxeig = int(m)
    else:
        maxeig = int(maxeig)
    maxpick = maxeig
    # covariace matrix
    cov = np.matmul(x, np.transpose(x)) / n
    # Eigen value decomposition
    eig_val, eig_vec = np.linalg.eig(cov)
    eig_vec_trp = np.transpose(eig_vec)
    eig_val_sqrt = eig_val ** (-0.5)

    # pick maxeig largest values
    eig_vec_trpm = eig_vec_trp[:maxpick]
    eig_val_sqrtm = eig_val_sqrt[:maxpick]

    # eig_val_dia=np.diag(eig_val)
    eig_val_sqrt_dia = np.diag(eig_val_sqrtm)
    whi = np.matmul(eig_val_sqrt_dia, eig_vec_trpm)
    x_white = np.matmul(whi, x)
    return x_white


def getExp(x):
    m, n = np.shape(x)
    exp = np.mean(x, axis=1)
    ex = np.reshape(exp, (m, 1))
    return ex


# one-unit ICA :produce one unit a time
def do_fastICA(x, maxtimes, minval, W_in=None):
    m, n = np.shape(x)
    # inialize a w (is a vector)
    if W_in is None:
        W = np.random.rand(m, m)
        for i in range(m):
            W[i] = W[i] / np.linalg.norm(W[i])
    else:
        W = W_in
        # do one iteration on W
    for i in range(m):
        w = W[i]
        wold = 2 * w
        counter = 0
        while np.abs(np.abs(np.matmul(w, np.transpose(wold))) - 1) > minval:
            wold = w
            counter = counter + 1
            y = np.matmul(w, x)
            gy = y * np.exp(-0.5 * (y ** 2))
            gdy = (1 - y ** 2) * np.exp(-0.5 * (y ** 2))
            w_next = getExp(x * gy) - np.average(gdy) * w.reshape(m, 1)  # n*1
            w_next_tr = w_next.reshape(m)  # 1*n
            #######make w[i] independent
            if i == 0:
                w = w_next_tr / np.linalg.norm(w_next_tr)
            else:
                w_add = np.zeros((m,))
                for n in range(i):
                    c = np.matmul(W[n], w_next)
                    w_add = w_add + c * W[n]
                w_next_dep = w_next_tr - w_add
                w = w_next_dep / np.linalg.norm(w_next_dep)
            if counter == maxtimes:
                print('Cannot find more signals')
                z = np.matmul(W, x)
                return z, W
        W[i] = w
    z = np.matmul(W, x)
    return z, W


def splicing(x_new, x_old, overlap):
    x_new_op = x_new[:, :overlap]
    x_old_op = x_old[:, -overlap:]
    x_new_app = x_new[:, overlap:]

    m, n = np.shape(x_new)
    x_app = x_new_app * 0
    for i in range(m):
        test_m = x_new_op - x_old_op[i]
        test_p = x_new_op + x_old_op[i]
        norm_m = np.zeros((m,))
        norm_p = np.zeros((m,))
        for j in range(m):
            norm_m[j] = np.linalg.norm(test_m[j])
            norm_p[j] = np.linalg.norm(test_p[j])
        m_sort = np.argsort(norm_m)
        p_sort = np.argsort(norm_p)
        m_min = norm_m[m_sort[0]]
        p_min = norm_p[p_sort[0]]
        if m_min <= p_min:
            sel = m_sort[0]
            m_p = 1
        else:
            sel = p_sort[0]
            m_p = -1
        x_app[i] = m_p * x_new_app[sel]
    xout = np.append(x_old, x_app, axis=1)
    return xout

def main():
    app = QApplication(sys.argv)
    ex = Test()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()